# saku_cnn
CNN for easy experiments
